# Palavra, Mesa e Missão — Volume 7

Autor e responsável editorial: Rev. Cleverson Gomes Corrêa.

Arquivamento de 10 de novembro de 2026.

Estado: Três cadernos recuperados; conferência editorial integral pendente.

Abra `index.html` para escolher a leitura. Os arquivos Word e PDF preservam suas versões recuperadas. A presença dos arquivos não representa uma revisão teológica integral concluída.

